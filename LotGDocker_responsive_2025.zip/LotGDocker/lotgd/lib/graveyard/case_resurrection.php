<?php
output("`\$%s`0 waves his skeletal arms as he begins to command the very fabric of life.`n`n",$deathoverlord);
// Note to translators.  The text spoken by Ramius here is backwards
// English.  You might choose to maintain it in tact, or you might choose
// to translate it to your language, and reverse the letters that way.  A
// few words have been replaced with latin counterparts to make it a
// little harder to identify that they are just backwards english.
// tu shall have resurrection
// rise from the dead o servant
// power over death is mine
// your life ego grant tu again
// for ego know tu shall return to me again
output("\"`)Noitcerruser evah llahs ut...`\$\"  The air begins to crackle around you.`n`n");
output("\"`)Tnavres o htaed eht morf esir.`\$\" Your soul begins to burn with the pain of a thousand frosty fires.`n`n");
output("\"`)Enim si htaed revo rewop.`\$\" Gradually you begin to become aware that the fires are dimming and are replaced by the blinding pain last known by your body before it fell.`n`n");
output("\"`)Niaga ut tnarg oge efil ruoy.`\$\" You begin to look around you, and you watch as your muscles knit themselves back together.`n`n");
output("\"`)Niaga em ot nruter llahs ut wonk oge rof.`\$\" With a gasp, you laboriously again draw your first breath.");
addnav("Continue","newday.php?resurrection=true");
?>
